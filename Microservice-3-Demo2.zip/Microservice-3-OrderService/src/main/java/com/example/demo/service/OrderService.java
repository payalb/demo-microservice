package com.example.demo.service;

import com.example.demo.dto.Order;

public interface OrderService {

	Order createOrder(Order order);

	Order getOrderById(long id);

	Order getOrderByUserId(long userid);

}
