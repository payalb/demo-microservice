package com.example.demo.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.dao.OrderRepository;
import com.example.demo.dto.Order;

@Component
public class DataSeeder implements CommandLineRunner {
	
	@Autowired private OrderRepository orderRepository; // Assuming you have an OrderRepository for data access

	@Override
	public void run(String... args) throws Exception {
		Order order1 = new Order();
		order1.setUserId(1);
		order1.setItems(List.of("Product1", "Product2"));
		order1.setPrice(200.0f); // Set the price of the order
		order1.setStatus("Pending");
		orderRepository.save(order1);
	}

	
}
