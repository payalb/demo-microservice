package com.example.demo.dto;

import java.util.HashMap;
import java.util.Map;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

//Represents user cart info
@Entity
public class Cart{
	@Id
	@GeneratedValue
	private int cartId;
	private int userId;
	@ElementCollection
	private Map<Integer, String> products= new HashMap<>();
	private float totalPrice;
	public Cart() {
	}
	public Cart( int userId) {
		super();
		this.userId = userId;
	}
	public int getCartId() {
		return cartId;
	}

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}


	public Map<Integer, String> getProducts() {
		return products;
	}

	public void setProducts(Map<Integer, String> products) {
		this.products = products;
	}
	public OrderRequest getOrderRequest() {
		OrderRequest request= new OrderRequest();
		request.setItems(products.values().stream().toList());
		request.setUserId(userId);
		request.setStatus("Pending");
		request.setPrice(totalPrice);
		return request;
	}


}
