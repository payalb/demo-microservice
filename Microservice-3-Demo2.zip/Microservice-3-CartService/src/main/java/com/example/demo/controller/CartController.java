package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.Cart;
import com.example.demo.service.CartService;

@RestController
@RequestMapping("/users/{userId}/cart")
public class CartController {
	
	@Autowired CartService cartService;
	
	@PostMapping
	public ResponseEntity<Long> saveCart(@RequestBody Cart cart) {
		long orderId=  cartService.saveCart(cart);
		//Modify it later to return the created user with a 201 status code	and the location of the created resource in the response header
		return new ResponseEntity<>(orderId, HttpStatus.CREATED);
	}
	// Add more endpoints as needed for user management, e.g., getUserById, updateUser, deleteUser, etc.
	@GetMapping
	public ResponseEntity<Cart> getCartByUserId(@PathVariable int userId) {
		Cart cart = cartService.getCartByUserId(userId);
		if (cart != null) {
			return new ResponseEntity<>(cart, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
