#key value pairs, key : unique and immutable: hashtable
#value can be any type
# preserve insertion order
student = {
    "name": "Alice",
    "age": 20
}

print(student["name"])
print(student.get("name"))
print(student.get("address", "Not Provided")) #default value

d2= dict({"name": "anuj", "age": 30})
print(d2)

#add or update:
student["address"] = "Delhi"
student.pop("address") #remove by key, returns value
del student["age"]  #delete by key
#student.clear() #remove all items

if "name" in student:
    print(student["name"])

for x in student.keys():
    print(x)

for y in student.values():
    print(y)

for key,value in student.items():
    print(key , value)

