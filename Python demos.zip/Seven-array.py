#of same data type
from array import array
x = array('i', [1,2,3]) #typecode: what datatype it should hold



