a = 33
b = 22
c= 15
if a > b and a > c:
    print(a)
elif b > a and b > c:
    print(b)
else:
    print(c)

if not a > b:
    print (b)

if a != b:
    print("Not equals")

if b > a:
    pass  # if no content in if

