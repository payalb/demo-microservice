package com.example.demo.util;

public class ExceptionMessage extends Exception {

	public ExceptionMessage(String message, int status, String reasonPhrase, String string2, String url) {
		super(message + " | Status: " + status + " | Reason: " + reasonPhrase + " | URL: " + url);
	}

}
