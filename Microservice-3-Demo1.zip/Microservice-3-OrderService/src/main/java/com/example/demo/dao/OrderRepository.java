package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.dto.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

	Order findByUserId(long userid);
	// Additional query methods can be defined here if needed
	// For example, you can define methods to find orders by userId or status

}
